﻿using System;

public class Kvadrat1
{
    public double Stranica { get; set; }

    public Kvadrat1(double stranica)
    {
        Stranica = stranica;
    }

    public double IzracunajPloscino()
    {
        return Stranica * Stranica;
    }

    public double IzracunajObseg()
    {
        return 4 * Stranica;
    }
}


public class Kvadrat2
{
    private double stranica;

    public Kvadrat2()
    {
        stranica = 0; 
    }

    public void NastaviStranico(double novaStranica)
    {
        if (novaStranica < 0)
        {
            stranica = 0;
        }
        else
        {
            stranica = novaStranica;
        }
    }

    public double IzracunajPloscino()
    {
        return stranica * stranica;
    }

    public double IzracunajObseg()
    {
        return 4 * stranica;
    }
}

class Program
{
    static void Main()
    {
        
        Kvadrat1 kvadrat1A = new Kvadrat1(5);
        Kvadrat1 kvadrat1B = new Kvadrat1(8);

        Console.WriteLine("Kvadrat1 A - Ploščina: " + kvadrat1A.IzracunajPloscino() + ", Obseg: " + kvadrat1A.IzracunajObseg());
        Console.WriteLine("Kvadrat1 B - Ploščina: " + kvadrat1B.IzracunajPloscino() + ", Obseg: " + kvadrat1B.IzracunajObseg());

        Kvadrat2 kvadrat2A = new Kvadrat2();
        Kvadrat2 kvadrat2B = new Kvadrat2();

        kvadrat2A.NastaviStranico(6);
        kvadrat2B.NastaviStranico(-3);

        Console.WriteLine("Kvadrat2 A - Ploščina: " + kvadrat2A.IzracunajPloscino() + ", Obseg: " + kvadrat2A.IzracunajObseg());
        Console.WriteLine("Kvadrat2 B - Ploščina: " + kvadrat2B.IzracunajPloscino() + ", Obseg: " + kvadrat2B.IzracunajObseg());
    }
}   