﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vaja1
{
    using System;

    public class Denarnica
    {
        private double stanje; 

        public Denarnica()
        {
            stanje = 0;
        }

        
        public Denarnica(Denarnica drugaDenarnica)
        {
            stanje = drugaDenarnica.stanje;
        }

        
        public Denarnica(double zacetnoStanje)
        {
            if (zacetnoStanje >= 0)
            {
                stanje = zacetnoStanje;
            }
            else
            {
                stanje = 0;
            }
        }

        public bool Dvig(double vsota)
        {
            if (vsota > 0 && stanje >= vsota)
            {
                stanje -= vsota;
                return true; 
            }
            else
            {
                return false; 
            }
        }

        
        public void Polog(double vsota)
        {
            if (vsota > 0)
            {
                stanje += vsota;
            }
        }

    
        public double VrniStanje()
        {
            return stanje;
        }
    }

    class Program
    {
        static void Main()
        {
           
            Denarnica denarnica1 = new Denarnica(); 
            Denarnica denarnica2 = new Denarnica(50);

            bool uspeh = denarnica1.Dvig(30);
            if (uspeh)
            {
                Console.WriteLine("Uspešno ste dvignili 30 € iz denarnice 1.");
            }
            else
            {
                Console.WriteLine("Dvig iz denarnice 1 ni uspel.");
            }

            denarnica2.Polog(20);

         
            Console.WriteLine("Stanje v denarnici 1: " + denarnica1.VrniStanje() + " €");
            Console.WriteLine("Stanje v denarnici 2: " + denarnica2.VrniStanje() + " €");

            Denarnica denarnica3 = new Denarnica(denarnica1);

            Console.WriteLine("Stanje v denarnici 3 (kopirana iz denarnice 1): " + denarnica3.VrniStanje() + " €");
        }
    }

}
